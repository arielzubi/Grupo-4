package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MarcaDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public MarcaDao() {
    }
    //Agregar marca
    public boolean agregarMarca(Marca marca){
        String query = "INSERT INTO marca (marca) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getNombreMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la marca" + e);
            return false;
        }
    }
    
    //Modificar marca
    public boolean modificarMarca(Marca marca){
        String query = "UPDATE marca SET marca = ? WHERE id_marca = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getNombreMarca());
            pst.setInt(2, marca.getIdMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la marca" + e);
            return false;
        }
    }

    //Borrar marca
    public boolean borrarMarca(int id){
        String query = "DELETE FROM marca WHERE id_marca = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la marca" + e);
            return false;
        }
    }

    //Listar marca
    public List listarMarca(){
        List<Marca> list_marcas = new ArrayList();
        String query = "SELECT * FROM marca ORDER BY marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Marca marca = new Marca();
                marca.setIdMarca(rs.getInt("id_marca"));
                marca.setNombreMarca(rs.getString("marca"));
                list_marcas.add(marca);
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_marcas;
    }

    public List listarMarcaBusqueda(String busqueda){
        List<Marca> list_marcas = new ArrayList();
        String query = "SELECT * FROM marca WHERE marca LIKE '%"+ busqueda +"%'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Marca marca = new Marca();
                marca.setIdMarca(rs.getInt("id_marca"));
                marca.setNombreMarca(rs.getString("marca"));
                list_marcas.add(marca);
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_marcas;
    }
    
    //Buscar id de marca
    public int buscarIdMarca(String nombre){
        int id = 0;
        String query = "SELECT id_marca FROM marca WHERE marca = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("id_marca");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de marca" + e);
        }
        return id;
    }

}