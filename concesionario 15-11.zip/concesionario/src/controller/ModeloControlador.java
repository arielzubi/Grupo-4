/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.ModeloDao;
import view.Pantalla;
import model.MarcaDao;


/**
 *
 * @author rodri
 */
public class ModeloControlador implements ActionListener, MouseListener, KeyListener{
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Pantalla panta;
 
    DefaultTableModel model = new DefaultTableModel();
    
    
    public ModeloControlador(Modelo modelo, ModeloDao modeloDao, Pantalla panta) {
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.panta = panta;
        
                        //Botón de registrar producto
        this.panta.btn_AgregarModelo.addActionListener(this);
        
        //Botón de modificar producto
        this.panta.btn_ModificarModelo.addActionListener(this);
        
        //Botón de borrar producto
        this.panta.btn_BorrarModelo.addActionListener(this);
        
        //Botón de limpiar
        this.panta.btn_LimpiarModelo.addActionListener(this);
        
        //Listado de producto
        this.panta.tb_Modelo.addMouseListener(this);
        
        this.panta.txt_BuscarModelo.addKeyListener(this);
        
        //this.panta.txt_ResultadosModelo.addKeyListener(this);
              
        listarModelos(); 

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        
                //AGREGAR MODELO
        
        if(e.getSource() == panta.btn_AgregarModelo){
            //verifica si el campo está vacío
            if(panta.txt_NombreModelo.getText().equals("")||panta.cmb_MarcaModelo.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            }else{
                //Realiza el agregado
                String nombreSinFormatear = panta.txt_NombreModelo.getText();
                String nombreFormateado = nombreSinFormatear.substring(0, 1).toUpperCase() + nombreSinFormatear.substring(1).toLowerCase();
                modelo.setNombreModelo(nombreFormateado);

                MarcaDao marcaDao = new MarcaDao();
                int idMarca = marcaDao.buscarIdMarca(panta.cmb_MarcaModelo.getSelectedItem().toString());
                modelo.setIdMarca(idMarca);
                
                
                
               if(modeloDao.agregarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se agregó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el Modelo");
                    
                }
            }
            
            //MODIFICAR MODELO
            
        }else if(e.getSource() == panta.btn_ModificarModelo){
            //verifica si el campo está vacío
                            
            if(panta.txt_IdModelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un Modelo desde la tabla");
            }else{
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("pablo")){
                //Realiza la modificación
                modelo.setIdModelo(Integer.parseInt(panta.txt_IdModelo.getText()));
                String nombreSinFormatear = panta.txt_NombreModelo.getText();
                String nombreFormateado = nombreSinFormatear.substring(0, 1).toUpperCase() + nombreSinFormatear.substring(1).toLowerCase();
                modelo.setNombreModelo(nombreFormateado);
                MarcaDao marcaDao = new MarcaDao();
                int idMarca = marcaDao.buscarIdMarca(panta.cmb_MarcaModelo.getSelectedItem().toString());
                modelo.setIdMarca(idMarca);
                

                if(modeloDao.modificarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    panta.btn_AgregarModelo.setEnabled(true);
                    
                    JOptionPane.showMessageDialog(null, "Se modificó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el Modelo");
                }
                }else{
                 JOptionPane.showMessageDialog(null,"Clave incorrecta");
             }
            }
             
             
             //BORRAR MODELO
             
        }else if(e.getSource() == panta.btn_BorrarModelo){
            
            //verifica si el campo está vacío
            if(panta.txt_IdModelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un Modelo a borrar");
            }else{
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("pablo")){
                //Realiza el borrado
                int idmodelo = Integer.parseInt(panta.txt_IdModelo.getText());
                if(modeloDao.borrarModelo(idmodelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    panta.btn_AgregarModelo.setEnabled(true);
                    
                    JOptionPane.showMessageDialog(null, "Se eliminó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el Modelo");
                }
                }else{
                 JOptionPane.showMessageDialog(null,"Clave incorrecta");
                }
                }
             
             //LIMPIAR MODELO
             
        }else if(e.getSource() == panta.btn_LimpiarModelo){
                limpiarTabla();
                limpiarCampos();
                listarModelos();    
                panta.btn_AgregarModelo.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Modelo){
            int row = panta.tb_Modelo.rowAtPoint(e.getPoint());
            panta.txt_IdModelo.setText(panta.tb_Modelo.getValueAt(row,2).toString());
            panta.txt_NombreModelo.setText(panta.tb_Modelo.getValueAt(row,3).toString());
            panta.cmb_MarcaModelo.setSelectedItem(panta.tb_Modelo.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_AgregarModelo.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource() == panta.txt_BuscarModelo){
            listarModelos();
        }
    }

    //Listar todos los productos
    public void listarModelos(){
        if(panta.txt_BuscarModelo.getText().equals("")){
            panta.cmb_ModeloAuto.removeAllItems();
        panta.cmb_ModeloVersion.removeAllItems();
        panta.cmb_ModeloAuto.addItem("");
        panta.cmb_ModeloVersion.addItem("");
        panta.txt_ResultadosModelo.setText("");
            
        List<Modelo> list = modeloDao.listarModelo();
        model = (DefaultTableModel) panta.tb_Modelo.getModel();
        Object[] row = new Object[4];
        limpiarTabla();
        
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdMarca();
            row[1] = list.get(i).getNombreMarca();
            row[2] = list.get(i).getIdModelo();
            row[3] = list.get(i).getNombreModelo();
            model.addRow(row);
            
            panta.cmb_ModeloAuto.addItem(list.get(i).getNombreModelo());
            panta.cmb_ModeloVersion.addItem(list.get(i).getNombreModelo());
        }
    
    }else{
        String busqueda = panta.txt_BuscarModelo.getText();
        List<Modelo> list1 = modeloDao.listarModeloBusqueda(busqueda);
        model = (DefaultTableModel) panta.tb_Modelo.getModel();
        Object[] row = new Object[4];
        limpiarTabla();
        String contador;
        int suma = 0;
         panta.cmb_ModeloAuto.removeAllItems();
         panta.cmb_ModeloVersion.removeAllItems();
        for(int i = 0; i < list1.size(); i++){
            row[0] = list1.get(i).getIdMarca();
            row[1] = list1.get(i).getNombreMarca();
            row[2] = list1.get(i).getIdModelo();
            row[3] = list1.get(i).getNombreModelo();
            model.addRow(row);
            
            panta.cmb_ModeloAuto.addItem(list1.get(i).getNombreModelo());
            panta.cmb_ModeloVersion.addItem(list1.get(i).getNombreModelo());
            suma = suma + 1;
    }
        contador = String.valueOf(suma);
        panta.txt_ResultadosModelo.setText(contador + " Resultados");
    }
    }
    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }

    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_IdModelo.setText("");
        panta.txt_NombreModelo.setText("");
        panta.cmb_MarcaModelo.setSelectedItem("");
        panta.txt_ResultadosModelo.setText("");
    }  
}
