package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.MarcaDao;
import model.Version;
import model.VersionDao;
import view.Pantalla;
import model.ModeloDao;

public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Version version;
    private VersionDao versionDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();
    
    
    public VersionControlador(Version version, VersionDao versionDao, Pantalla panta) {
        this.version = version;
        this.versionDao = versionDao;
        this.panta = panta;
        
        //Botón de registrar version
        this.panta.btn_AgregarVersion.addActionListener(this);
        //Botón de modificar version
        this.panta.btn_ModificarVersion.addActionListener(this);
        //Botón de borrar version
        this.panta.btn_BorrarVersion.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_LimpiarVersion.addActionListener(this);
        
        //Listado de version
        this.panta.tb_Version.addMouseListener(this);
        
        this.panta.txt_BuscarVersion.addKeyListener(this);
              
        listarVersion(); 
        
    }

////////    MODIFICADOR
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_AgregarVersion){
            //verifica si el campo nombre está vacío
            if(panta.txt_NombreVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                version.setNombreVersion(panta.txt_NombreVersion.getText());
                
                MarcaDao marcaDao = new MarcaDao();
                int idMarca = marcaDao.buscarIdMarca(panta.cmb_MarcaVersion.getSelectedItem().toString());
                version.setIdMarca(idMarca);

                ModeloDao modeloDao = new ModeloDao();
                int idModelo = modeloDao.buscarIdModelo(panta.cmb_ModeloVersion.getSelectedItem().toString());
                version.setIdModelo(idModelo);

                
                
                
                if(versionDao.agregarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se agregó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la version");
                }
            }
            //MODIFICAR VERSION
            
        }else if(e.getSource() == panta.btn_ModificarVersion){
            //verifica si el campo id está vacío
            if(panta.txt_IdVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("pablo")){
                    
////               Realiza la modificación
                version.setIdVersion(Integer.parseInt(panta.txt_IdVersion.getText()));
                version.setNombreVersion(panta.txt_NombreVersion.getText());
                MarcaDao marcaDao = new MarcaDao();
                int IdMarca = marcaDao.buscarIdMarca(panta.cmb_MarcaVersion.getSelectedItem().toString());
                ModeloDao modeloDao = new ModeloDao();
                int IdModelo = modeloDao.buscarIdModelo(panta.cmb_ModeloVersion.getSelectedItem().toString());
                
                version.setIdMarca(IdMarca);
                version.setIdModelo(IdModelo);
                
                if(versionDao.modificarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se modificó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la version");
                }
            }else {JOptionPane.showMessageDialog(null,"Clave incorrecta");
                }
                }
////            BORRADOR
        }else if(e.getSource() == panta.btn_BorrarVersion){
            //verifica si el campo id está vacío
            if(panta.txt_IdVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("pablo")){
//            
                    //Realiza el borrado
                int id = Integer.parseInt(panta.txt_IdVersion.getText());
                if(versionDao.borrarVersion(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se eliminó la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la version");
                }
            }else{JOptionPane.showMessageDialog(null,"Clave incorrecta");
                }
                }
        }else if(e.getSource() == panta.btn_LimpiarVersion){
                limpiarTabla();
                limpiarCampos();
                listarVersion();    
                panta.btn_AgregarVersion.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Version){
            int row = panta.tb_Version.rowAtPoint(e.getPoint());
            panta.cmb_MarcaVersion.setSelectedItem(panta.tb_Version.getValueAt(row,1).toString());
            panta.cmb_ModeloVersion.setSelectedItem(panta.tb_Version.getValueAt(row,3).toString());
            panta.txt_IdVersion.setText(panta.tb_Version.getValueAt(row,4).toString());
            panta.txt_NombreVersion.setText(panta.tb_Version.getValueAt(row,5).toString());

            //Deshabilitar
            panta.btn_AgregarVersion.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource()== panta.txt_BuscarVersion){
            listarVersion();
        }
    }

////    Listar todas las versiones
    public void listarVersion(){
        
        if(panta.txt_BuscarVersion.getText().equals("")){
        panta.cmb_VersionAuto.removeAllItems();
        panta.cmb_VersionAuto.addItem("");
        panta.txt_ResultadosVersion.setText("");

        List<Version> list = versionDao.listarVersion();
        model = (DefaultTableModel) panta.tb_Version.getModel();
        Object[] row = new Object[6];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdMarca();
            row[1] = list.get(i).getNombreMarca();
            row[2] = list.get(i).getIdModelo();
            row[3] = list.get(i).getNombreModelo();
            row[4] = list.get(i).getIdVersion();
            row[5] = list.get(i).getNombreVersion();
            
            
            model.addRow(row);
            
            panta.cmb_VersionAuto.addItem(list.get(i).getNombreVersion());

        }
        }else{
            panta.cmb_VersionAuto.removeAllItems();
            panta.cmb_VersionAuto.addItem("");
            
        String busqueda = panta.txt_BuscarVersion.getText();
        List<Version> list = versionDao.listarVersionBusqueda(busqueda);
        model = (DefaultTableModel) panta.tb_Version.getModel();
        Object[] row = new Object[6];
        limpiarTabla();
        String contador;
        int suma = 0;
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdMarca();
            row[1] = list.get(i).getNombreMarca();
            row[2] = list.get(i).getIdModelo();
            row[3] = list.get(i).getNombreModelo();
            row[4] = list.get(i).getIdVersion();
            row[5] = list.get(i).getNombreVersion();
            
            
            model.addRow(row);
            
            panta.cmb_VersionAuto.addItem(list.get(i).getNombreVersion());
            suma = suma + 1;
        }
        contador = String.valueOf(suma);
        panta.txt_ResultadosVersion.setText(contador + " Resultados");
    }
    }


////    Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_IdVersion.setText("");
        panta.txt_NombreVersion.setText("");
        panta.cmb_MarcaVersion.setSelectedItem("");
        panta.cmb_ModeloVersion.setSelectedItem("");
        panta.txt_ResultadosVersion.setText("");
    }
    
}