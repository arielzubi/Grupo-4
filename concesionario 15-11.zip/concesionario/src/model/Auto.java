/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author estudiante
 */
public class Auto {
     private int idauto;
     private int idmarca;
     private int idmodelo;
     private int idversion;
     private int año ;
     private double precio ;
     private String tipo ;
     private int kilometraje;
     private int puertas;
     private String combustible;
     private String condicion;
     
     private String nombremarca;
     private String nombremodelo;
     private String nombreversion;
     
     

    public Auto() {
    }

    public Auto(int idauto, int idmarca, int idmodelo, int idversion, int año, double precio, String tipo, int kilometraje, int puertas, String combustible, String condicion, String nombremarca, String nombremodelo, String nombreversion) {
        this.idauto = idauto;
        this.idmarca = idmarca;
        this.idmodelo = idmodelo;
        this.idversion = idversion;
        this.año = año;
        this.precio = precio;
        this.tipo = tipo;
        this.kilometraje = kilometraje;
        this.puertas = puertas;
        this.combustible = combustible;
        this.condicion = condicion;
        this.nombremarca = nombremarca;
        this.nombremodelo = nombremodelo;
        this.nombreversion = nombreversion;
    }

    public int getIdauto() {
        return idauto;
    }

    public void setIdauto(int idauto) {
        this.idauto = idauto;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public String getNombremarca() {
        return nombremarca;
    }

    public void setNombremarca(String nombremarca) {
        this.nombremarca = nombremarca;
    }

    public String getNombremodelo() {
        return nombremodelo;
    }

    public void setNombremodelo(String nombremodelo) {
        this.nombremodelo = nombremodelo;
    }

    public String getNombreversion() {
        return nombreversion;
    }

    public void setNombreversion(String nombreversion) {
        this.nombreversion = nombreversion;
    }

    @Override
    public String toString() {
        return "Auto{" + "idauto=" + idauto + ", idmarca=" + idmarca + ", idmodelo=" + idmodelo + ", idversion=" + idversion + ", a\u00f1o=" + año + ", precio=" + precio + ", tipo=" + tipo + ", kilometraje=" + kilometraje + ", puertas=" + puertas + ", combustible=" + combustible + ", condicion=" + condicion + ", nombremarca=" + nombremarca + ", nombremodelo=" + nombremodelo + ", nombreversion=" + nombreversion + '}';
    }

   
     
     
     
    
}
