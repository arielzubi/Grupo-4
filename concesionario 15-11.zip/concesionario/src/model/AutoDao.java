/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author estudiante
 */
public class AutoDao {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    int a;

    public AutoDao() {
    }
     //Agregar auto
    public boolean agregarAuto(Auto auto){
        String query = "INSERT INTO auto (id_auto, id_marca, id_modelo, id_version, anio, precio, kilometros, puertas, combustible, condicion, tipo) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdauto());
            pst.setInt(2,auto.getIdmarca());
            pst.setInt(3,auto.getIdmodelo());
            pst.setInt(4,auto.getIdversion());
            pst.setInt(5,auto.getAño());
            pst.setDouble(6,auto.getPrecio());
            pst.setInt(7,auto.getKilometraje());
            pst.setInt(8,auto.getPuertas());
            pst.setString(9,auto.getCombustible());
            pst.setString(10,auto.getCondicion());
            pst.setString(11,auto.getTipo());
         
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el auto" + e);
            return false;
        }
    }

     //Modificar auto
    public boolean modificarAuto(Auto auto){
        String query = "UPDATE auto SET  id_marca = ?, id_modelo = ?, id_version = ?, anio = ?, precio = ?, kilometros = ?,puertas = ?,combustible = ?, condicion = ?,tipo = ? WHERE id_auto = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdmarca());
            pst.setInt(2,auto.getIdmodelo());
            pst.setInt(3,auto.getIdversion());
            pst.setInt(4,auto.getAño());
            pst.setDouble(5,auto.getPrecio());
            pst.setInt(6,auto.getKilometraje());
            pst.setInt(7,auto.getPuertas());
            pst.setString(8,auto.getCombustible());
            pst.setString(9,auto.getCondicion());
            pst.setString(10,auto.getTipo());
            pst.setInt(11,auto.getIdauto());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el auto" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarAuto(int id){
        String query = "DELETE FROM auto WHERE id_auto = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el auto" + e);
            return false;
        }
    }

    //Listar auto
    public List listarAuto(){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT A.id_auto, MA.marca, MO.modelo, V.version, A.anio, A.precio, A.kilometros,"
                + " A.puertas, A.combustible, A.condicion,A.tipo FROM auto AS A INNER JOIN marca AS MA "
                + "ON A.id_marca = MA.id_marca INNER JOIN modelo AS MO ON A.id_modelo = MO.id_modelo INNER JOIN version AS V"
                + " ON A.id_version =V.id_version ORDER BY marca ASC;";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdauto(rs.getInt("id_auto"));
                auto.setNombremarca(rs.getString("marca"));
                auto.setNombremodelo(rs.getString("modelo"));
                auto.setNombreversion(rs.getString("version"));
                auto.setAño(rs.getInt("anio"));
                auto.setPrecio(rs.getDouble("precio"));
                auto.setKilometraje(rs.getInt("kilometros"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setCondicion(rs.getString("condicion"));
                auto.setTipo(rs.getString("tipo"));
                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    }    
    
    
        public List listarAutoBusqueda(String busqueda){
        List<Auto> list_autosBusqueda = new ArrayList();
        String query = "SELECT A.id_auto, MA.marca, MO.modelo, V.version, A.anio AS año, A.precio, A.kilometros, A.puertas, A.combustible, A.condicion,A.tipo FROM auto AS A INNER JOIN marca AS MA ON A.id_marca = MA.id_marca INNER JOIN modelo AS MO ON A.id_modelo = MO.id_modelo INNER JOIN version AS V ON A.id_version =V.id_version where Ma.marca LIKE '%" + busqueda+"%'";
        a = 0;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                 auto.setIdauto(rs.getInt("id_auto"));
                auto.setNombremarca(rs.getString("marca"));
                auto.setNombremodelo(rs.getString("modelo"));
                auto.setNombreversion(rs.getString("version"));
                auto.setAño(rs.getInt("año"));
                auto.setPrecio(rs.getDouble("precio"));
                auto.setKilometraje(rs.getInt("kilometros"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setCondicion(rs.getString("condicion"));
                auto.setTipo(rs.getString("tipo"));
                list_autosBusqueda.add(auto);
                a = a + 1;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
        if(a == 0){
        String query1 = "SELECT A.id_auto, MA.marca, MO.modelo, V.version, A.anio AS año, A.precio, A.kilometros, A.puertas, A.combustible, A.condicion,A.tipo FROM auto AS A INNER JOIN marca AS MA ON A.id_marca = MA.id_marca INNER JOIN modelo AS MO ON A.id_modelo = MO.id_modelo INNER JOIN version AS V ON A.id_version =V.id_version where  MO.modelo LIKE '%" + busqueda+"%'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query1);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                 auto.setIdauto(rs.getInt("id_auto"));
                auto.setNombremarca(rs.getString("marca"));
                auto.setNombremodelo(rs.getString("modelo"));
                auto.setNombreversion(rs.getString("version"));
                auto.setAño(rs.getInt("año"));
                auto.setPrecio(rs.getDouble("precio"));
                auto.setKilometraje(rs.getInt("kilometros"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setCondicion(rs.getString("condicion"));
                auto.setTipo(rs.getString("tipo"));
                list_autosBusqueda.add(auto);
                a = a + 1;
            }
            } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            }
        }
        
        if(a == 0){
            String query1 = "SELECT A.id_auto, MA.marca, MO.modelo, V.version, A.anio AS año, A.precio, A.kilometros, A.puertas, A.combustible, A.condicion,A.tipo FROM auto AS A INNER JOIN marca AS MA ON A.id_marca = MA.id_marca INNER JOIN modelo AS MO ON A.id_modelo = MO.id_modelo INNER JOIN version AS V ON A.id_version =V.id_version where  V.version LIKE '%" + busqueda+"%'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query1);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                 auto.setIdauto(rs.getInt("id_auto"));
                auto.setNombremarca(rs.getString("marca"));
                auto.setNombremodelo(rs.getString("modelo"));
                auto.setNombreversion(rs.getString("version"));
                auto.setAño(rs.getInt("año"));
                auto.setPrecio(rs.getDouble("precio"));
                auto.setKilometraje(rs.getInt("kilometros"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setCondicion(rs.getString("condicion"));
                auto.setTipo(rs.getString("tipo"));
                list_autosBusqueda.add(auto);
            }
            } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            }
        }
        return list_autosBusqueda;
    }

}
       
    
    

