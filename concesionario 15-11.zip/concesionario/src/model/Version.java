/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author rodri
 */
public class Version {
    int idVersion;
    String nombreVersion;
    int idMarca;
    int idModelo;
    
    String nombreMarca;
    String nombreModelo;

    public Version() {
    }

    public Version(int idVersion, String nombreVersion, int idMarca, int idModelo, String nombreMarca, String nombreModelo) {
        this.idVersion = idVersion;
        this.nombreVersion = nombreVersion;
        this.idMarca = idMarca;
        this.idModelo = idModelo;
        this.nombreMarca = nombreMarca;
        this.nombreModelo = nombreModelo;
    }

    public String getNombreMarca() {
        return nombreMarca;
    }

    public void setNombreMarca(String nombreMarca) {
        this.nombreMarca = nombreMarca;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public void setNombreModelo(String nombreModelo) {
        this.nombreModelo = nombreModelo;
    }

    public int getIdVersion() {
        return idVersion;
    }

    public void setIdVersion(int idVersion) {
        this.idVersion = idVersion;
    }

    public String getNombreVersion() {
        return nombreVersion;
    }

    public void setNombreVersion(String nombreVersion) {
        this.nombreVersion = nombreVersion;
    }

    public int getIdMarca() {
        return idMarca;
    }

    public void setIdMarca(int idMarca) {
        this.idMarca = idMarca;
    }

    public int getIdModelo() {
        return idModelo;
    }

    public void setIdModelo(int idModelo) {
        this.idModelo = idModelo;
    }

    @Override
    public String toString() {
        return "Version{" + "idVersion=" + idVersion + ", nombreVersion=" + nombreVersion + ", idMarca=" + idMarca + ", idModelo=" + idModelo + ", nombreMarca=" + nombreMarca + ", nombreModelo=" + nombreModelo + '}';
    }

 

    
}