package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.swing.JOptionPane;

public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public VersionDao() {
    }
////    Agregar version
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (version, id_modelo, id_marca) VALUES(?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.setInt(2,version.getIdModelo());
            pst.setInt(3,version.getIdMarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la version" + e);
            return false;
        }
    }
    
    //Modificar version
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET version = ?, id_marca= ?, id_modelo= ? WHERE id_version = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.setInt(4, version.getIdVersion());
            pst.setInt(2, version.getIdMarca());
            pst.setInt(3, version.getIdModelo());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la version" + e);
            return false;
        }
    }

    //Borrar version
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE id_version = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la version" + e);
            return false;
        }
    }

    //Listar version
    public List listarVersion(){
        List<Version> list_version = new ArrayList();
        String query = "SELECT V.id_marca, MA.marca, V.id_modelo, MO.modelo, V.id_version, V.version FROM version AS V INNER JOIN marca AS MA ON V.id_marca = MA.id_marca INNER JOIN modelo AS MO ON V.id_modelo = MO.id_modelo ORDER BY version ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdMarca(rs.getInt("id_marca"));
                version.setNombreMarca(rs.getString("marca"));
                version.setIdModelo(rs.getInt("id_modelo"));
                version.setNombreModelo(rs.getString("modelo"));
                version.setIdVersion(rs.getInt("id_version"));
                version.setNombreVersion(rs.getString("version"));
                
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }

public List listarVersionBusqueda(String busqueda){
        List<Version> list_version = new ArrayList();
        String query = "SELECT V.id_marca, MA.marca, V.id_modelo, MO.modelo, V.id_version, V.version FROM version AS V INNER JOIN marca AS MA ON V.id_marca = MA.id_marca INNER JOIN modelo AS MO ON V.id_modelo = MO.id_modelo WHERE version LIKE '%" + busqueda+"%'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdMarca(rs.getInt("id_marca"));
                version.setNombreMarca(rs.getString("marca"));
                version.setIdModelo(rs.getInt("id_modelo"));
                version.setNombreModelo(rs.getString("modelo"));
                version.setIdVersion(rs.getInt("id_version"));
                version.setNombreVersion(rs.getString("version"));
                
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }

public List listarVersionesParaCombo(String modeloSeleccionado){
        List<Version> list_versionparacombo = new ArrayList();
        String query = "SELECT V.version FROM version AS V INNER JOIN modelo AS MO ON V.id_modelo = MO.id_modelo WHERE MO.modelo ='" + modeloSeleccionado +"'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setNombreVersion(rs.getString("version"));
                
                list_versionparacombo.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_versionparacombo;
    }

    
////   Buscar id de version
    public int buscarIdVersion(String nombre){
        int id = 0;
        String query = "SELECT id_version FROM version WHERE version = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("id_version");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);
        }
        return id;
    }

}