package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import view.Pantalla;

public class MarcaControlador implements ActionListener, MouseListener, KeyListener {
    private Marca marca;
    private MarcaDao marcaDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();


    public MarcaControlador(Marca marca, MarcaDao marcaDao, Pantalla panta) {
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.panta = panta;
        
        //Botón de registrar marca
        this.panta.btn_AgregarMarca.addActionListener(this);
        //Botón de modificar marca
        this.panta.btn_ModificarMarca.addActionListener(this);
        //Botón de borrar marca
        this.panta.btn_BorrarMarca.addActionListener(this);
        //Botón de limpiar marca
        this.panta.btn_LimpiarMarca.addActionListener(this);
        
        //Listado de marca
        this.panta.tb_Marca.addMouseListener(this);
        
        this.panta.txt_BuscarMarca.addKeyListener(this);
        
        //this.panta.txt_ResultadosMarca.addKeyListener(this);
              
        listarMarcas(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_AgregarMarca){
            //verifica si el campo nombre está vacío
            if(panta.txt_NombreMarca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                 String NombreMarca = panta.txt_NombreMarca.getText();
                 if (!NombreMarca.isEmpty()) {
                NombreMarca = NombreMarca.substring(0, 1).toUpperCase() + NombreMarca.substring(1).toLowerCase();
            }
                marca.setNombreMarca(NombreMarca);
                if(marcaDao.agregarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se agregó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la marca");
                }
            }
        }else if(e.getSource() == panta.btn_ModificarMarca){
            //verifica si el campo id está vacío
            if(panta.txt_IdMarca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("")){
                //Realiza la modificación
                marca.setIdMarca(Integer.parseInt(panta.txt_IdMarca.getText()));                
                
                String NombreMarca = panta.txt_NombreMarca.getText();
                
                 if (!NombreMarca.isEmpty()) {
                NombreMarca = NombreMarca.substring(0, 1).toUpperCase() + NombreMarca.substring(1).toLowerCase();
            }
                
                 marca.setNombreMarca(NombreMarca);
                if(marcaDao.modificarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    panta.btn_AgregarMarca.setEnabled(true);
                    JOptionPane.showMessageDialog(null, "Se modificó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la marca");
                }
                }else{
                    JOptionPane.showMessageDialog(null,"Clave incorrecta");
                }
            }
        }else if(e.getSource() == panta.btn_BorrarMarca){
            //verifica si el campo id está vacío
            if(panta.txt_IdMarca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                String clave = JOptionPane.showInputDialog(null,"Ingrese su clave de acceso a la base de datos");
                if(clave != null && clave.equals("")){
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_IdMarca.getText());
                if(marcaDao.borrarMarca(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    panta.btn_AgregarMarca.setEnabled(true);
                    JOptionPane.showMessageDialog(null, "Se eliminó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la marca");
                }
                }else{
                   JOptionPane.showMessageDialog(null,"Clave incorrecta"); 
                }
            }
        }else if(e.getSource() == panta.btn_LimpiarMarca){
                limpiarTabla();
                limpiarCampos();
                listarMarcas();    
                panta.btn_AgregarMarca.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Marca){
            int row = panta.tb_Marca.rowAtPoint(e.getPoint());
            panta.txt_IdMarca.setText(panta.tb_Marca.getValueAt(row,0).toString());
            panta.txt_NombreMarca.setText(panta.tb_Marca.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_AgregarMarca.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource()== panta.txt_BuscarMarca){
            listarMarcas();
        }
        
    }

    //Listar todas las marcas
    public void listarMarcas(){
           
        if(panta.txt_BuscarMarca.getText().equals("")){
        panta.cmb_MarcaAuto.removeAllItems();
        panta.cmb_MarcaModelo.removeAllItems();
        panta.cmb_MarcaVersion.removeAllItems();
        panta.cmb_MarcaAuto.addItem("");
        panta.cmb_MarcaModelo.addItem("");
        panta.cmb_MarcaVersion.addItem("");
        panta.txt_ResultadosMarca.setText("Resultados: ");

        List<Marca> list = marcaDao.listarMarca();
        model = (DefaultTableModel) panta.tb_Marca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdMarca();
            row[1] = list.get(i).getNombreMarca();
            model.addRow(row);
            
            panta.cmb_MarcaAuto.addItem(list.get(i).getNombreMarca());
            panta.cmb_MarcaModelo.addItem(list.get(i).getNombreMarca());
            panta.cmb_MarcaVersion.addItem(list.get(i).getNombreMarca());
        }
        }else{
           panta.cmb_MarcaAuto.removeAllItems();
           panta.cmb_MarcaModelo.removeAllItems();
           panta.cmb_MarcaVersion.removeAllItems();
           panta.cmb_MarcaAuto.addItem("");
           panta.cmb_MarcaModelo.addItem("");
           panta.cmb_MarcaVersion.addItem("");
           
           String busqueda = panta.txt_BuscarMarca.getText();
           List<Marca> list1 = marcaDao.listarMarcaBusqueda(busqueda);
        model = (DefaultTableModel) panta.tb_Marca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        String contador;
        int suma = 0;
        for(int i = 0; i < list1.size(); i++){
            row[0] = list1.get(i).getIdMarca();
            row[1] = list1.get(i).getNombreMarca();
            model.addRow(row);
            
            panta.cmb_MarcaAuto.addItem(list1.get(i).getNombreMarca());
            panta.cmb_MarcaModelo.addItem(list1.get(i).getNombreMarca());
            panta.cmb_MarcaVersion.addItem(list1.get(i).getNombreMarca());
            suma = suma + 1;
 
         }
        contador = String.valueOf(suma);
        panta.txt_ResultadosMarca.setText("Resultados: " + contador);
         }
        }
    


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_IdMarca.setText("");
        panta.txt_NombreMarca.setText("");
        panta.txt_ResultadosMarca.setText("");
        panta.txt_BuscarMarca.setText("");
        panta.txt_ResultadosMarca.setText("");
    }
    
}