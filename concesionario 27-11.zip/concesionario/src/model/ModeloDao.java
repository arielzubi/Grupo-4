/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.Connection;// PARA CONECTARME CON SQL DEBO SIEMPRE IMPORTAR ESTO
import java.sql.PreparedStatement;// Y ESTO
import java.sql.ResultSet;//Y ESTO
import java.sql.SQLException;// Y ESTO
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import view.Pantalla;

/**
 *
 * @author rodri
 */
public class ModeloDao {
        //instanciar la conexion: crear un objeto
    Conexion cn= new Conexion();
    Connection con;
    PreparedStatement pst;//guardo lo que le ordeno a mysql
    ResultSet rs;//guardo lo que recibo de mysql


    public ModeloDao() {
    }
    
        public boolean agregarModelo(Modelo modelo){
        String query= "INSERT INTO modelo (modelo, id_marca) VALUES(?,?)";
        try{
            con= cn.conectar();
            pst= con.prepareStatement(query);
            pst.setString(1,modelo.getNombreModelo());
            pst.setInt(2,modelo.getIdMarca());
            pst.execute();
            return true;
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Error al registrar el Modelo" + e);
            return false;
        }
    }
    public boolean modificarModelo(Modelo modelo){
        String query= "UPDATE modelo SET modelo= ?, id_marca= ? WHERE id_modelo= ?";
        try{
            con = cn.conectar();
            pst= con.prepareStatement(query);
            pst.setInt(3, modelo.getIdModelo());
            pst.setInt(2, modelo.getIdMarca());
            pst.setString(1, modelo.getNombreModelo());
            pst.execute();
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error al modificar el Modelo" + e);
            return false;
        }
    }
    public boolean borrarModelo(int idmodelo){
        String query= "DELETE FROM modelo WHERE id_modelo= "+ idmodelo;
        try{
            con= cn.conectar();
            pst= con.prepareStatement(query);
            pst.execute();
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error al borrar el Modelo" + e);
            return false;
        }
        
    }
    public List listarModelo(){
        List<Modelo> list_modelo = new ArrayList();
        String query = "SELECT MA.id_marca, MA.marca, MO.id_modelo, MO.modelo FROM modelo AS MO INNER JOIN marca AS MA ON MO.id_marca = MA.id_marca ORDER BY modelo ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Modelo modelo = new Modelo();
                modelo.setIdMarca(rs.getInt("id_marca"));
                modelo.setNombreMarca(rs.getString("marca"));
                modelo.setIdModelo(rs.getInt("id_modelo"));
                modelo.setNombreModelo(rs.getString("modelo"));
               
                
                list_modelo.add(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_modelo;
    }

    public List listarModeloBusqueda(String busqueda){
        List<Modelo>list_modelosBusqueda= new ArrayList();
        String query= "SELECT MO.id_modelo, MO.modelo, MO.id_marca, MA.marca FROM modelo AS MO INNER JOIN marca AS MA ON MO.id_marca = MA.id_marca where  modelo LIKE '%" + busqueda+"%' ORDER BY modelo ASC";
        try{
            con= cn.conectar();
            pst= con.prepareStatement(query);
            rs= pst.executeQuery();
            while(rs.next()){
                Modelo modelo= new Modelo();
                modelo.setIdMarca(rs.getInt("id_marca"));
                modelo.setNombreMarca(rs.getString("marca"));
                modelo.setIdModelo(rs.getInt("id_modelo"));
                modelo.setNombreModelo(rs.getString("modelo"));
                list_modelosBusqueda.add(modelo);
                
               
            }
        }catch (SQLException e){
                    JOptionPane.showMessageDialog(null, e.toString());
                    }
            return list_modelosBusqueda;
        }
    
    public List listarModelosParaCombo(String marcaSeleccionada){
        List<Modelo> list_modeloparacombo = new ArrayList();
        String query = "SELECT MO.modelo FROM modelo AS MO INNER JOIN marca AS MA ON MO.id_marca = MA.id_marca WHERE MA.marca = '" + marcaSeleccionada + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Modelo modelo = new Modelo();
                modelo.setNombreModelo(rs.getString("modelo"));
                
                list_modeloparacombo.add(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_modeloparacombo;
    }


    public int buscarIdModelo(String nombre){
        int id = 0;
        String query = "SELECT id_modelo FROM modelo WHERE modelo = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("id_modelo");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de modelo" + e);
        }
        return id;
    }
    
    
}
