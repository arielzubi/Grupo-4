/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.ModeloDao;
import view.Pantalla;


/**
 *
 * @author rodri
 */
public class ModeloControlador implements ActionListener, MouseListener, KeyListener{
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Pantalla panta;
 
    DefaultTableModel model = new DefaultTableModel();

    public ModeloControlador(Modelo modelo, ModeloDao modeloDao, Pantalla panta) {
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.panta = panta;
        
                        //Botón de registrar producto
        this.panta.btn_AgregarModelo.addActionListener(this);
        
        //Botón de modificar producto
        this.panta.btn_ModificarModelo.addActionListener(this);
        
        //Botón de borrar producto
        this.panta.btn_BorrarModelo.addActionListener(this);
        
        //Botón de limpiar
        this.panta.btn_LimpiarModelo.addActionListener(this);
        
        //Listado de producto
        this.panta.tb_Modelo.addMouseListener(this);
              
        listarModelos(); 

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_AgregarModelo){
            //verifica si el campo está vacío
            if(panta.txt_NombreModelo.getText().equals("")){//panta.cmb_MarcaModelo.getSelectedItem().equals("")
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            }else{
                //Realiza el agregado
               // modelo.setIdModelo(Integer.parseInt(panta.txt_IdModelo.getText()));
                modelo.setNombreModelo(panta.txt_NombreModelo.getText());
                
                
                
               if(modeloDao.agregarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se agregó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el Modelo");
                }
            }
        }else if(e.getSource() == panta.btn_ModificarModelo){
            //verifica si el campo está vacío
            if(panta.txt_IdModelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un Modelo a modificar");
            }else{
                //Realiza la modificación
                modelo.setIdModelo(Integer.parseInt(panta.txt_IdModelo.getText()));
                modelo.setNombreModelo(panta.txt_NombreModelo.getText());
                if(modeloDao.modificarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se modificó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el Modelo");
                }
            }
        }else if(e.getSource() == panta.btn_BorrarModelo){
            //verifica si el campo está vacío
            if(panta.txt_IdModelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un Modelo a borrar");
            }else{
                //Realiza el borrado
                int idmodelo = Integer.parseInt(panta.txt_IdModelo.getText());
                if(modeloDao.borrarModelo(idmodelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se eliminó el Modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el Modelo");
                }
            }
        }else if(e.getSource() == panta.btn_LimpiarModelo){
                limpiarTabla();
                limpiarCampos();
                listarModelos();    
                panta.btn_AgregarModelo.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Modelo){
            int row = panta.tb_Modelo.rowAtPoint(e.getPoint());
            panta.txt_IdModelo.setText(panta.tb_Modelo.getValueAt(row,0).toString());
            panta.txt_NombreModelo.setText(panta.tb_Modelo.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_AgregarModelo.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los productos
    public void listarModelos(){
        panta.cmb_ModeloAuto.removeAllItems();
        panta.cmb_ModeloVersion.removeAllItems();
        
        List<Modelo> list = modeloDao.listarModelo(panta);
        model = (DefaultTableModel) panta.tb_Modelo.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdModelo();
            row[1] = list.get(i).getNombreModelo();
            model.addRow(row);
            panta.cmb_ModeloAuto.addItem(list.get(i).getNombreModelo());
            panta.cmb_ModeloVersion.addItem(list.get(i).getNombreModelo());
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_IdModelo.setText("");
        panta.txt_NombreModelo.setText("");
    }
    
}
