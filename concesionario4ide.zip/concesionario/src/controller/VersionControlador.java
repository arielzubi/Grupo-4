package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Version;
import model.VersionDao;
import view.Pantalla;

public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Version version;
    private VersionDao versionDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public VersionControlador(Version version, VersionDao versionDao, Pantalla panta) {
        this.version = version;
        this.versionDao = versionDao;
        this.panta = panta;
        
        //Botón de registrar version
        this.panta.btn_AgregarVersion.addActionListener(this);
        //Botón de modificar version
        this.panta.btn_ModificarVersion.addActionListener(this);
        //Botón de borrar version
        this.panta.btn_BorrarVersion.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_LimpiarVersion.addActionListener(this);
        
        //Listado de version
        this.panta.tb_Version.addMouseListener(this);
              
        listarVersion(); 
        
    }

////////    MODIFICADOR
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_AgregarVersion){
            //verifica si el campo nombre está vacío
            if(panta.txt_NombreVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                version.setNombreVersion(panta.txt_NombreVersion.getText());
                if(versionDao.agregarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se agregó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el género");
                }
            }
        }else if(e.getSource() == panta.btn_ModificarVersion){
            //verifica si el campo id está vacío
            if(panta.txt_IdVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
////               Realiza la modificación
                version.setIdVersion(Integer.parseInt(panta.txt_IdVersion.getText()));
                version.setNombreVersion(panta.txt_NombreVersion.getText());
                if(versionDao.modificarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se modificó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el género");
                }
            }
////            BORRADOR
        }else if(e.getSource() == panta.btn_BorrarVersion){
            //verifica si el campo id está vacío
            if(panta.txt_IdVersion.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
////             Realiza el borrado
                int id = Integer.parseInt(panta.txt_IdVersion.getText());
                if(versionDao.borrarVersion(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersion();
                    JOptionPane.showMessageDialog(null, "Se eliminó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el género");
                }
            }
        }else if(e.getSource() == panta.btn_LimpiarVersion){
                limpiarTabla();
                limpiarCampos();
                listarVersion();    
                panta.btn_AgregarVersion.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Version){
            int row = panta.tb_Version.rowAtPoint(e.getPoint());
            panta.txt_IdVersion.setText(panta.tb_Version.getValueAt(row,0).toString());
            panta.txt_NombreVersion.setText(panta.tb_Version.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_AgregarVersion.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

////    Listar todas las versiones
    public void listarVersion(){
        
        panta.cmb_VersionAuto.removeAllItems();

        List<Version> list = versionDao.listarVersion();
        model = (DefaultTableModel) panta.tb_Version.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdVersion();
            row[1] = list.get(i).getNombreVersion();
            model.addRow(row);
            
            panta.cmb_VersionAuto.addItem(list.get(i).getNombreVersion());

        }
    }


////    Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_IdVersion.setText("");
        panta.txt_NombreVersion.setText("");
    }
    
}