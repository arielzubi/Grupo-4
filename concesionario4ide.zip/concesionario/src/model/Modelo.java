/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author rodri
 */
public class Modelo {
    int idModelo;
    String nombreModelo;
    int idMarca;

    public Modelo() {
    }

    public Modelo(int idModelo, String nombreModelo, int idMarca) {
        this.idModelo = idModelo;
        this.nombreModelo = nombreModelo;
        this.idMarca = idMarca;
    }

    
    public int getIdModelo() {
        return idModelo;
    }

    public void setIdModelo(int idModelo) {
        this.idModelo = idModelo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public void setNombreModelo(String nombreModelo) {
        this.nombreModelo = nombreModelo;
    }

    public int getIdMarca() {
        return idMarca;
    }

    public void setIdMarca(int idMarca) {
        this.idMarca = idMarca;
    }
    

    @Override
    public String toString() {
        return "Modelo{" + "idModelo=" + idModelo + ", nombreModelo=" + nombreModelo + '}';
    }

    
    
}
