/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author rodri
 */
public class Version {
    int idVersion;
    String nombreVersion;

    public Version() {
    }

    public Version(int idVersion, String nombreVersion) {
        this.idVersion = idVersion;
        this.nombreVersion = nombreVersion;
    }

    public int getIdVersion() {
        return idVersion;
    }

    public void setIdVersion(int idVersion) {
        this.idVersion = idVersion;
    }

    public String getNombreVersion() {
        return nombreVersion;
    }

    public void setNombreVersion(String nombreVersion) {
        this.nombreVersion = nombreVersion;
    }

    @Override
    public String toString() {
        return "Version{" + "idVersion=" + idVersion + ", nombreVersion=" + nombreVersion + '}';
    }

    
    
}
