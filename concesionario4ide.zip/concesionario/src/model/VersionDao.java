package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public VersionDao() {
    }
////    Agregar version
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (version) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el version" + e);
            return false;
        }
    }
    
    //Modificar version
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET version = ? WHERE id_version = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombreVersion());
            pst.setInt(2, version.getIdVersion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el version" + e);
            return false;
        }
    }

    //Borrar version
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE id_version = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el version" + e);
            return false;
        }
    }

    //Listar version
    public List listarVersion(){
        List<Version> list_version = new ArrayList();
        String query = "SELECT * FROM version ORDER BY version ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdVersion(rs.getInt("id_version"));
                version.setNombreVersion(rs.getString("version"));
                list_version.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_version;
    }    
    
////   Buscar id de version
    public int buscarIdVersion(String nombre){
        int id = 0;
        String query = "SELECT id_version FROM version WHERE version = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("id_version");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);
        }
        return id;
    }

}